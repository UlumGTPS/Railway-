# UlumStore — Railway Fixed Build

This package is a Node.js web service for Railway. It uses `server.js` and a
Dockerfile so Railway does not need to guess the build system.

## Required Railway Variables

- `MIDTRANS_MODE` = `production` (use `sandbox` for testing)
- `MIDTRANS_SERVER_KEY` = your Midtrans Server Key
- `DOWNLOAD_SC_AUTO_GROWCH` = final download URL
- `DOWNLOAD_VMOSGAGA` = final download URL

Never put the Midtrans Server Key in frontend files.

## Deploy

1. Upload/extract this project to the Railway service.
2. Railway should detect `Dockerfile`.
3. Deploy.
4. Open the generated Railway domain and confirm the UlumStore page loads.
5. Configure the four variables above before testing payments.

The malformed `worker/index.js` from the previous package has intentionally been
removed because it contained HTML `<script>` blocks inside a JavaScript Worker
file and was syntactically invalid. The Railway service does not need that file.
