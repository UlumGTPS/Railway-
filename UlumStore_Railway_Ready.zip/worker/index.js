
<script>
function getCurrentRole(){return localStorage.getItem('ulumRole')||'member'}
function setMemberVIP(){localStorage.setItem('ulumRole','vip');localStorage.setItem('ulumVipSince',new Date().toISOString());renderRoleBadge()}
function setAdminRole(){localStorage.setItem('ulumRole','administrator_reseller');renderRoleBadge()}
function isAdmin(){return getCurrentRole()==='administrator_reseller'}
function isVip(){return ['vip','administrator_reseller'].includes(getCurrentRole())}
function renderRoleBadge(){document.querySelectorAll('[data-role-badge],#memberRoleBadge,.member-role-badge').forEach(el=>{let r=getCurrentRole();el.textContent=r==='administrator_reseller'?'Administrator + Reseller':r==='vip'?'VIP':'Member';el.classList.toggle('vip',r!=='member')})}
function guardAdminAction(){if(!isAdmin()){typeof toast==='function'&&toast('Fitur ini khusus Administrator + Reseller.');return false}return true}
function editLockPrice(lockId,price){if(!guardAdminAction())return;let d=JSON.parse(localStorage.getItem('ulumLockPrices')||'{}');d[lockId]=Number(price);localStorage.setItem('ulumLockPrices',JSON.stringify(d));typeof toast==='function'&&toast('Harga lock berhasil diperbarui.')}
function editProduct(productId,changes){if(!guardAdminAction())return;let d=JSON.parse(localStorage.getItem('ulumProducts')||'{}');d[productId]={...(d[productId]||{}),...changes};localStorage.setItem('ulumProducts',JSON.stringify(d));typeof toast==='function'&&toast('Produk berhasil diperbarui.')}
</script>

<script>
function memberPurchasedProducts(){
  try{return JSON.parse(localStorage.getItem('ulumMemberPurchasedProducts')||'[]')}catch(e){return[]}
}
function saveMemberPurchasedProduct(product){
  const a=memberPurchasedProducts();
  if(product && !a.some(x=>x.name===product.name)) a.push(product);
  localStorage.setItem('ulumMemberPurchasedProducts',JSON.stringify(a));
}
function renderMemberDownloads(){
  const box=document.getElementById('memberDownloads');
  if(!box)return;
  const items=memberPurchasedProducts();
  box.innerHTML=items.length ? items.map((p,i)=>`
    <div class="member-download-item">
      <div><b>${escapeHtml(p.name)}</b><small>${escapeHtml(p.orderId||'Pembelian terverifikasi')}</small></div>
      <a class="btn" href="${escapeAttr(p.downloadUrl)}" target="_blank" rel="noopener">Download</a>
    </div>`).join('') :
    '<div class="muted">Belum ada produk yang berhasil dibayar.</div>';
}
function escapeAttr(v){return String(v||'').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}
</script>
const PRODUCTS = {
  "SC Auto Growch": { price: 15000, env: "DOWNLOAD_SC_AUTO_GROWCH" },
  "VMOSGAGA": { price: 15000, env: "DOWNLOAD_VMOSGAGA" },
};

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" },
  });
}

function corsHeaders(request) {
  const origin = request.headers.get("Origin") || "*";
  return { "Access-Control-Allow-Origin": origin, "Access-Control-Allow-Methods": "GET,POST,OPTIONS", "Access-Control-Allow-Headers": "Content-Type" };
}

async function midtransFetch(env, path, init = {}) {
  const base = (env.MIDTRANS_MODE || "production").toLowerCase() === "sandbox"
    ? "https://api.sandbox.midtrans.com"
    : "https://api.midtrans.com";
  const auth = btoa(`${env.MIDTRANS_SERVER_KEY}:`);
  const headers = new Headers(init.headers || {});
  headers.set("Authorization", `Basic ${auth}`);
  headers.set("Content-Type", "application/json");
  return fetch(base + path, { ...init, headers });
}

async function createPayment(request, env) {
  const body = await request.json().catch(() => null);
  if (!body) return json({ error: "JSON tidak valid" }, 400);
  const product = PRODUCTS[body.product];
  if (!product) return json({ error: "Produk tidak valid" }, 400);
  if (!env.MIDTRANS_SERVER_KEY) return json({ error: "MIDTRANS_SERVER_KEY belum diatur" }, 500);

  const orderId = `ULUM-${Date.now()}-${crypto.randomUUID().slice(0, 8).toUpperCase()}`;
  const payload = {
    payment_type: "qris",
    transaction_details: { order_id: orderId, gross_amount: product.price },
    item_details: [{ id: body.product.replace(/\s+/g, "-").toLowerCase(), price: product.price, quantity: 1, name: body.product }],
    customer_details: { first_name: String(body.member || "UlumStore Member").slice(0, 40) },
    qris: { acquirer: "gopay" },
  };

  const res = await midtransFetch(env, "/v2/charge", { method: "POST", body: JSON.stringify(payload) });
  const data = await res.json().catch(() => ({}));
  if (!res.ok || !data.transaction_id) return json({ error: data.status_message || "Gagal membuat transaksi QRIS", detail: data }, 502);
  const action = (data.actions || []).find(x => x.name === "generate-qr-code-v2") || (data.actions || []).find(x => x.name === "generate-qr-code");
  return json({ orderId, product: body.product, amount: product.price, status: data.transaction_status || "pending", qrUrl: action?.url || null, expiresAt: data.expiry_time || null });
}

async function getStatus(orderId, env) {
  if (!/^ULUM-[0-9]{10,}-[A-Z0-9]{8}$/.test(orderId)) return json({ error: "Order ID tidak valid" }, 400);
  const res = await midtransFetch(env, `/v2/${encodeURIComponent(orderId)}/status`, { method: "GET" });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) return json({ error: data.status_message || "Order tidak ditemukan" }, res.status === 404 ? 404 : 502);
  const product = PRODUCTS_BY_PRICE(data.gross_amount);
  const paid = data.transaction_status === "settlement" || (data.transaction_status === "capture" && data.fraud_status === "accept");
  return json({ orderId, status: paid ? "PAID" : String(data.transaction_status || "pending").toUpperCase(), paid, product: product?.name || null, amount: Number(data.gross_amount || 0), transactionId: data.transaction_id || null, paidAt: data.settlement_time || null });
}

function PRODUCTS_BY_PRICE(amount) {
  const n = Number(amount);
  const entry = Object.entries(PRODUCTS).find(([, p]) => p.price === n);
  return entry ? { name: entry[0], ...entry[1] } : null;
}

async function download(request, env) {
  const url = new URL(request.url);
  const orderId = url.searchParams.get("order_id") || "";
  const product = url.searchParams.get("product") || "";
  const item = PRODUCTS[product];
  if (!item) return new Response("Produk tidak valid", { status: 400 });
  const res = await midtransFetch(env, `/v2/${encodeURIComponent(orderId)}/status`, { method: "GET" });
  const data = await res.json().catch(() => ({}));
  const paid = res.ok && (data.transaction_status === "settlement" || (data.transaction_status === "capture" && data.fraud_status === "accept"));
  if (!paid || Number(data.gross_amount) !== item.price) return new Response("Pembayaran belum terverifikasi.", { status: 403 });
  const destination = env[item.env];
  if (!destination) return new Response("Link download belum dikonfigurasi admin.", { status: 503 });
  return Response.redirect(destination, 302);
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (request.method === "OPTIONS") return new Response(null, { headers: corsHeaders(request) });
    try {
      let response;
      if (url.pathname === "/api/create-payment" && request.method === "POST") response = await createPayment(request, env);
      else if (url.pathname.startsWith("/api/status/") && request.method === "GET") response = await getStatus(url.pathname.split("/").pop(), env);
      else if (url.pathname === "/download" && request.method === "GET") response = await download(request, env);
      else response = await env.ASSETS.fetch(request);
      const headers = new Headers(response.headers);
      Object.entries(corsHeaders(request)).forEach(([k, v]) => headers.set(k, v));
      return new Response(response.body, { status: response.status, headers });
    } catch (e) {
      return json({ error: "Server error", message: String(e?.message || e) }, 500);
    }
  }
};
<script>
function hasVipChatAccess(){try{let r=localStorage.getItem('ulumRole')||'member';return r==='vip'||r==='administrator_reseller'}catch(e){return false}}
</script>