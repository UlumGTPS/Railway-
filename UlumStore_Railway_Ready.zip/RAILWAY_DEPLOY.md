# UlumStore - Railway
Deploy this folder as a Railway service. Railway runs `npm start`.

Required Railway Variables:
- MIDTRANS_MODE=production (use sandbox for testing)
- MIDTRANS_SERVER_KEY=your Midtrans server key
- DOWNLOAD_SC_AUTO_GROWCH=https://...
- DOWNLOAD_VMOSGAGA=https://...

Do not put the Midtrans server key in frontend files or GitHub.
The frontend uses /api/create-payment, /api/status/:orderId and /download.
